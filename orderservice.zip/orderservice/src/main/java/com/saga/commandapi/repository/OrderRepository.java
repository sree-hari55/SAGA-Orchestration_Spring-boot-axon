package com.saga.commandapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.saga.commandapi.entity.OrderInfo;

public interface OrderRepository extends JpaRepository<OrderInfo,String> {

}
