package com.saga.commandapi.controller;

import java.util.UUID;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.saga.commandapi.command.CreateOrderCommand;
import com.saga.commandapi.dto.OrderDto;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/order/v1/command")
@Slf4j
public class OrderCommandController {

	@Autowired
	private transient CommandGateway commandGateWay;

	@PostMapping(path="/create")
	public ResponseEntity<String> saveOrder(@RequestBody OrderDto orderDto){
		log.info("order dto from request:{}"+orderDto);
		CreateOrderCommand createOrderCommand=CreateOrderCommand
				.builder()
				.orderId(UUID.randomUUID().toString())
				.productId(orderDto.getProductId())
				.userId(orderDto.getUserId())
				.orderStatus("Completed")
				.addressId(orderDto.getAddressId())
				.quantity(orderDto.getQuantity())
				.build();
		String response=commandGateWay.sendAndWait(createOrderCommand);
		return new ResponseEntity<String>(response,HttpStatus.CREATED);
	}

}
