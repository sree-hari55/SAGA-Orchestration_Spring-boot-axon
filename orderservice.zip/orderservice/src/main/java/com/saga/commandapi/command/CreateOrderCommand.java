package com.saga.commandapi.command;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreateOrderCommand {

	@TargetAggregateIdentifier
	protected String orderId;
	protected String productId;
	protected String userId;
	protected String addressId;
	protected Integer quantity;
	protected String orderStatus;
}
