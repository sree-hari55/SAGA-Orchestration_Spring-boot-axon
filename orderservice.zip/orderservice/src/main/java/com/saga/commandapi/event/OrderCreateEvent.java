package com.saga.commandapi.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderCreateEvent {

	protected String orderId;
	protected String productId;
	protected String userId;
	protected String addressId;
	protected Integer quantity;
	protected String orderStatus;
}
