package com.saga.commandapi.aggregate;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.modelling.command.AggregateLifecycle;
import org.axonframework.spring.stereotype.Aggregate;
import org.springframework.beans.BeanUtils;

import com.saga.command.CancelOrderCommand;
import com.saga.command.CompleteOrderCommand;
import com.saga.commandapi.command.CreateOrderCommand;
import com.saga.commandapi.event.OrderCreateEvent;
import com.saga.event.OrderCancelledEvent;
import com.saga.event.OrderCompletedEvent;

@Aggregate
public class OrderAggregate {

	@AggregateIdentifier
	protected String orderId;
	protected String productId;
	protected String userId;
	protected String addressId;
	protected Integer quantity;
	protected String orderStatus;


	public OrderAggregate() {
		super();
	}

	@CommandHandler
	public  OrderAggregate(CreateOrderCommand command) {
		// validation 
		OrderCreateEvent orderCreateEvent=new OrderCreateEvent();
		BeanUtils.copyProperties(command, orderCreateEvent);
		AggregateLifecycle.apply(orderCreateEvent);
	}

	@EventSourcingHandler
	public void on(OrderCreateEvent orderCreateEvent) {
		this.orderId=orderCreateEvent.getOrderId();
		this.orderStatus= orderCreateEvent.getOrderStatus();
		this.addressId=orderCreateEvent.getAddressId();
		this.productId=orderCreateEvent.getProductId();
		this.userId=orderCreateEvent.getUserId();
		this.quantity=orderCreateEvent.getQuantity();
	}

	@CommandHandler
	public void completeOrderCommandhandler(CompleteOrderCommand command) {
		OrderCompletedEvent orderCompletedEvent=OrderCompletedEvent
				.builder()
				.orderId(command.getOrderId())
				.orderStatus(command.getOrderStatus())
				.build();
		AggregateLifecycle.apply(orderCompletedEvent);
	}

	@EventSourcingHandler
	public void on(CompleteOrderCommand event) {
		this.orderStatus= event.getOrderStatus();
	}

	@CommandHandler
	public void completeOrderCommandhandler(CancelOrderCommand command) {
		OrderCancelledEvent orderCancelledEvent=OrderCancelledEvent
				.builder()
				.orderId(command.getOrderId())
				.orderStatus(command.getOrderStatus())
				.build();
		AggregateLifecycle.apply(orderCancelledEvent);
	}

	@EventSourcingHandler
	public void on(OrderCancelledEvent event) {
		this.orderStatus= event.getOrderStatus();
	}
}
