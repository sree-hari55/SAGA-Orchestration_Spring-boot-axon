
package com.saga.commandapi.eventhandler;

import org.axonframework.eventhandling.EventHandler;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.saga.commandapi.entity.OrderInfo;
import com.saga.commandapi.event.OrderCreateEvent;
import com.saga.commandapi.repository.OrderRepository;
import com.saga.event.OrderCancelledEvent;
import com.saga.event.OrderCompletedEvent;

@Component
public class OrderEventHandler {
	
	@Autowired
	private OrderRepository orderRepository;

	@EventHandler
	public void on(OrderCreateEvent orderCreateEvent) {
		OrderInfo orderInfo=new OrderInfo();
		BeanUtils.copyProperties(orderCreateEvent, orderInfo);
		orderRepository.save(orderInfo);
	}
	
	@EventHandler
	public void on(OrderCompletedEvent orderCompletedEvent) {
		OrderInfo orderInfo=orderRepository.findById(orderCompletedEvent.getOrderId()).get();
		System.out.println("orderinfo:{}"+orderInfo.toString());
		orderInfo.setOrderStatus(orderCompletedEvent.getOrderStatus());
		orderRepository.save(orderInfo);
	}
	
	
	@EventHandler
	public void on(OrderCancelledEvent orderCancelledEvent ) {
		OrderInfo orderInfo=orderRepository.findById(orderCancelledEvent.getOrderId()).get();
		System.out.println("orderinfo:{}"+orderInfo.toString());
		orderInfo.setOrderStatus(orderCancelledEvent.getOrderStatus());
		orderRepository.save(orderInfo);
		
		// we can delete record as well 
		//orderRepository.deleteById(orderCancelledEvent.getOrderId());
	}

}
