package com.saga.commandapi.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor


@Entity
public class OrderInfo {

	@Id
	protected String orderId;
	protected String productId;
	protected String userId;
	protected String addressId;
	protected Integer quantity;
	protected String orderStatus;
}
