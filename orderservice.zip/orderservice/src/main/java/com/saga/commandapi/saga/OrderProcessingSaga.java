package com.saga.commandapi.saga;

import java.util.UUID;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.messaging.responsetypes.ResponseTypes;
import org.axonframework.modelling.saga.EndSaga;
import org.axonframework.modelling.saga.SagaEventHandler;
import org.axonframework.modelling.saga.StartSaga;
import org.axonframework.queryhandling.QueryGateway;
import org.axonframework.spring.stereotype.Saga;
import org.springframework.beans.factory.annotation.Autowired;

import com.saga.command.CancelOrderCommand;
import com.saga.command.CancelPaymentCommand;
import com.saga.command.CancelShipmentCommand;
import com.saga.command.CompleteOrderCommand;
import com.saga.command.ShipOrderCommand;
import com.saga.command.ValidatePaymentCommand;
import com.saga.commandapi.event.OrderCreateEvent;
import com.saga.dto.User;
import com.saga.event.OrderCancelledEvent;
import com.saga.event.OrderCompletedEvent;
import com.saga.event.OrderShipedEvent;
import com.saga.event.PaymentCancelledEvent;
import com.saga.event.PaymentProcessedEvent;
import com.saga.event.ShipmentCancelledEvent;
import com.saga.queries.GetUserPaymentDeatilsQuery;

import lombok.extern.slf4j.Slf4j;

@Saga
@Slf4j
public class OrderProcessingSaga {

	@Autowired
	private transient CommandGateway commandGateway;

	@Autowired
	private transient QueryGateway queryGateway;


	public OrderProcessingSaga() {
		super();
	}

	@SagaEventHandler(associationProperty = "orderId")
	@StartSaga
	private void handle(OrderCreateEvent orderCreateEvent) {
		log.info("Order created event in saga for orderId:{}"+orderCreateEvent.getOrderId());
		User user=null;

		GetUserPaymentDeatilsQuery getUserPaymentDeatilsQuery=new GetUserPaymentDeatilsQuery(orderCreateEvent.getUserId());


		try {
			user=queryGateway.query(getUserPaymentDeatilsQuery, ResponseTypes.instanceOf(User.class)).join();
		} catch (Exception e) {
			log.error(e.getMessage());
			//perform Compensating transaction
			cancelOrderCommand(orderCreateEvent.getOrderId());
		}
		ValidatePaymentCommand validatePaymentCommand=ValidatePaymentCommand
				.builder()
				.cardDetails(user.getCardDetails())
				.orderId(orderCreateEvent.getOrderId())
				.paymentId(UUID.randomUUID().toString())
				.build();
		commandGateway.sendAndWait(validatePaymentCommand);
	}

	private void cancelOrderCommand(String orderId) {
		CancelOrderCommand cancelOrderCommand=new CancelOrderCommand(orderId);
		commandGateway.send(cancelOrderCommand);
	}

	@SagaEventHandler(associationProperty ="orderId")
	private void handle(PaymentProcessedEvent event) {
		log.info("PaymentProcessedEcvent in saga for order id:{}"+event.getOrderId());
		try {
			
			ShipOrderCommand shipOrderCommand=ShipOrderCommand
					.builder()
					.shipmentId(UUID.randomUUID().toString())
					.orderId(event.getOrderId())
					.paymentId(event.getPaymentId())
					.build();
			commandGateway.sendAndWait(shipOrderCommand);
		} catch (Exception e) {
			log.error(e.getMessage());
			//perform compensating transaction
			cancelPaymentCommand(event);
		}

	}

	private void cancelPaymentCommand(PaymentProcessedEvent event) {
		CancelPaymentCommand cancelPaymentCommand=CancelPaymentCommand
				.builder()
				.orderId(event.getOrderId())
				.paymentId(event.getPaymentId())
				.build();
		commandGateway.send(cancelPaymentCommand);
	}

	@SagaEventHandler(associationProperty ="orderId")
	private void handle(OrderShipedEvent event) {
		log.info("OrderShipedEvent in saga for order id:{}"+event.getOrderId());

		try {
			CompleteOrderCommand completeOrderCommand=CompleteOrderCommand
					.builder()
					.orderId(event.getOrderId())
					.orderStatus("Approved")
					.build();

			commandGateway.send(completeOrderCommand);

		} catch (Exception e) {
			log.error(e.getMessage());
			cancelShipmentCommand(event);
		}
	}


	private void cancelShipmentCommand(OrderShipedEvent event) {
		System.out.println(event.getPaymentId());
		CancelShipmentCommand cancelShipmentCommand=CancelShipmentCommand.builder()
				.orderId(event.getOrderId())
				.paymentId(event.getPaymentId())
				.shipmentId(event.getShipmentId())
				.build();
		commandGateway.send(cancelShipmentCommand);
	}

	@SagaEventHandler(associationProperty ="orderId")
	@EndSaga
	private void handle(OrderCompletedEvent event) {
		log.info("OrderCompletedEvent in saga for order id:{}"+event.getOrderId());
	}

	@SagaEventHandler(associationProperty ="orderId")
	public void handle(OrderCancelledEvent orderCancelledEvent) {
		log.info("orderCancelledEvent in saga for order id:{}"+orderCancelledEvent.getOrderId());
	}

	@SagaEventHandler(associationProperty ="orderId")
	public void handle(PaymentCancelledEvent paymentCancelledEvent) {
		log.info("paymentCancelledEvent in saga for order id:{}"+paymentCancelledEvent.getOrderId());
		cancelOrderCommand(paymentCancelledEvent.getOrderId());
	}

	@SagaEventHandler(associationProperty ="orderId")
	public void handle(ShipmentCancelledEvent shipmentCancelledEvent) {
		log.info("shipmentCancelledEvent in saga for order id:{}"+shipmentCancelledEvent.getOrderId());
		// need to cancel payment & order 
		PaymentProcessedEvent paymentProcessedEvent=PaymentProcessedEvent.builder()
				.orderId(shipmentCancelledEvent.getOrderId())
				.paymentId(shipmentCancelledEvent.getPaymentId())
				.build();
		cancelPaymentCommand(paymentProcessedEvent);
	}

}
