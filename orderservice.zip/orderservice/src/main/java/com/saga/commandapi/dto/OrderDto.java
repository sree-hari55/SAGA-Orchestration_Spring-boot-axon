package com.saga.commandapi.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrderDto {
	
	protected String productId;
	protected String userId;
	protected String addressId;
	protected Integer quantity;
	

}
