package com.saga.command;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import com.saga.dto.CardDetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ValidatePaymentCommand {

	@TargetAggregateIdentifier
	protected String paymentId;
	protected String orderId;
	private CardDetails cardDetails;
}
