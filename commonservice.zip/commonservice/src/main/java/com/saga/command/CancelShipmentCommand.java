package com.saga.command;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Value;

@Data
@Builder
@AllArgsConstructor
@Value
public class CancelShipmentCommand {

	@TargetAggregateIdentifier
	protected String shipmentId;
	protected String orderId;
	protected String paymentId;
	protected String shipmentStatus="Cancelled";
}
