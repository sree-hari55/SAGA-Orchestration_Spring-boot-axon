package com.saga.command;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Value;

@Data
@Builder
@AllArgsConstructor
@Value
public class CancelOrderCommand {

	@TargetAggregateIdentifier
	protected String orderId;
	protected String orderStatus="Cancelled";
}
