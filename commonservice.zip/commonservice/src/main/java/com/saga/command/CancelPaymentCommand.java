package com.saga.command;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Value;

@Data
@Builder
@AllArgsConstructor
@Value
public class CancelPaymentCommand {

	@TargetAggregateIdentifier
	protected String paymentId;
	protected String orderId;
	protected String paymentStatus="Cancelled";
}
