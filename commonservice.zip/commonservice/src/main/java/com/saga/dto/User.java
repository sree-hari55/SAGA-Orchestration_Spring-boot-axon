package com.saga.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class User {
	protected String userId;
	protected String firstName;
	protected String lastName;
	protected CardDetails cardDetails;
}
