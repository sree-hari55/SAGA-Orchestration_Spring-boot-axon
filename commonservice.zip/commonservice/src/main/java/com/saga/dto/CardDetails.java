package com.saga.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CardDetails {

	protected String name;
	protected String cardNumber;
	protected Integer validUntilMonth;
	protected Integer validUntilYear;
	protected Integer cvv;
}
