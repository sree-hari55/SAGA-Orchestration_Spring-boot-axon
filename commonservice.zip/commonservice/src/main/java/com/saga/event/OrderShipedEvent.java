package com.saga.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrderShipedEvent {

	protected String shipmentId;
	protected String orderId;
	protected String shipmentStatus;
	protected String paymentId;
}
