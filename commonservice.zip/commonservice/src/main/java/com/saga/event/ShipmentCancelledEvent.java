package com.saga.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class ShipmentCancelledEvent {

	protected String shipmentId;
	protected String orderId;
	protected String paymentId;
	protected String shipmentStatus;
}
