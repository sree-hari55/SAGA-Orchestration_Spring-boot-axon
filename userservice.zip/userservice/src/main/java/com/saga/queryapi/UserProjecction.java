package com.saga.queryapi;

import org.axonframework.queryhandling.QueryHandler;
import org.springframework.stereotype.Component;

import com.saga.dto.CardDetails;
import com.saga.dto.User;
import com.saga.queries.GetUserPaymentDeatilsQuery;

@Component
public class UserProjecction {

	@QueryHandler
	public User getUserPaymentDeatils(GetUserPaymentDeatilsQuery query) {
		// get user data from db
		CardDetails cardDetails=CardDetails
				.builder()
				.name("sreehari")
				.cardNumber("1234567890")
				.validUntilMonth(01)
				.validUntilYear(2025)
				.cvv(123)
				.build();
		return User.builder().userId(query.getUserId()).firstName("sreehari").lastName("Golla").cardDetails(cardDetails).build();
		
	}
}
