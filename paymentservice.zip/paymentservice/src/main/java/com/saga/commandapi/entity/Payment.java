package com.saga.commandapi.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Payment {

	@Id
	protected String paymentId;
	protected String orderId;
	protected Date timeStamp;
	protected String paymentStatus;
}