package com.saga.commandapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.saga.commandapi.entity.Payment;

public interface PaymentRepository extends JpaRepository<Payment, String> {

}
