package com.saga.commandapi.aggregate;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.modelling.command.AggregateLifecycle;
import org.axonframework.spring.stereotype.Aggregate;

import com.saga.command.CancelPaymentCommand;
import com.saga.command.ValidatePaymentCommand;
import com.saga.event.PaymentCancelledEvent;
import com.saga.event.PaymentProcessedEvent;

import lombok.extern.slf4j.Slf4j;

@Aggregate
@Slf4j
public class PaymentAggreagte {

	@AggregateIdentifier
	protected String paymentId;
	protected String orderId;
	protected String paymentStatus;

	public PaymentAggreagte() {
	}

	@CommandHandler
	public PaymentAggreagte(ValidatePaymentCommand command) {
		//validate payment details
		// publish the payment processed event
		log.info("executing ValidatePaymentCommand with order Id:{} and payment id:{}"+command.getOrderId(),command.getPaymentId());
		PaymentProcessedEvent paymentProcessedEvent =
				new PaymentProcessedEvent(command.getPaymentId(),command.getOrderId());
		AggregateLifecycle.apply(paymentProcessedEvent);
		log.info("PaymentProccsedEvent Applied");
	}

	@EventSourcingHandler
	public void on(PaymentProcessedEvent event) {
		this.orderId=event.getOrderId();
		this.paymentId=event.getPaymentId();

	}

	@CommandHandler
	public void handle(CancelPaymentCommand command) {
		//validate payment details
		// publish the payment processed event
		log.info("executing CancelPaymentCommand with order Id:{} and payment id:{}"+command.getOrderId(),command.getPaymentId());
		PaymentCancelledEvent paymentCancelledEvent = PaymentCancelledEvent
				.builder()
				.orderId(command.getOrderId())
				.paymentId(command.getPaymentId())
				.paymentStatus(command.getPaymentStatus())
				.build();

		AggregateLifecycle.apply(paymentCancelledEvent);
		log.info("paymentCancelledEvent Applied");
	}

	@EventSourcingHandler
	public void on(PaymentCancelledEvent event) {
		this.paymentStatus=event.getPaymentStatus();

	}
}
