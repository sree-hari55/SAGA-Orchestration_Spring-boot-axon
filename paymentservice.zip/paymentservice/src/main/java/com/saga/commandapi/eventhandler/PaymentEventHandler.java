package com.saga.commandapi.eventhandler;

import java.util.Date;

import org.axonframework.eventhandling.EventHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.saga.commandapi.entity.Payment;
import com.saga.commandapi.repository.PaymentRepository;
import com.saga.event.PaymentCancelledEvent;
import com.saga.event.PaymentProcessedEvent;

@Component
public class PaymentEventHandler {

	@Autowired
	private PaymentRepository paymentRepository;
	
	@EventHandler
	public void on(PaymentProcessedEvent event) {
		Payment payment=Payment
				.builder()
				.paymentId(event.getPaymentId())
				.orderId(event.getOrderId())
				.timeStamp(new Date())
				.paymentStatus("Completed")
				.build();
		paymentRepository.save(payment);
	}
	
	@EventHandler
	public void on(PaymentCancelledEvent event) {
		Payment payment=paymentRepository.findById(event.getPaymentId()).get();
		System.out.println("payemnt info:{}"+payment.toString());
		payment.setPaymentStatus(event.getPaymentStatus());
		paymentRepository.save(payment);
		
		// we can delete record as well 
		//paymentRepository.deleteById(event.getPaymentId());
	}
}
