package com.saga.shipmentservice.aggreagte;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.modelling.command.AggregateLifecycle;
import org.axonframework.spring.stereotype.Aggregate;

import com.saga.command.CancelShipmentCommand;
import com.saga.command.ShipOrderCommand;
import com.saga.event.OrderShipedEvent;
import com.saga.event.ShipmentCancelledEvent;

@Aggregate
public class ShipmentAggregate {

	@AggregateIdentifier
	protected String shipmentId;
	protected String orderId;
	protected String paymentId;
	protected String shipmentStatus;


	public ShipmentAggregate() {
		super();
	}

	@CommandHandler
	public ShipmentAggregate(ShipOrderCommand command) {
		// validate command
		OrderShipedEvent orderShipedEvent=OrderShipedEvent
				.builder()
				.shipmentId(command.getShipmentId())
				.paymentId(command.getPaymentId())
				.orderId(command.getOrderId())
				.shipmentStatus("Completed")
				.build();	

		AggregateLifecycle.apply(orderShipedEvent);
	}

	@EventSourcingHandler
	public void on(OrderShipedEvent orderShipedEvent) {
		this.orderId=orderShipedEvent.getOrderId();
		this.shipmentId=orderShipedEvent.getShipmentId();
		this.shipmentStatus=orderShipedEvent.getShipmentStatus();
	}

	@CommandHandler
	public void handle(CancelShipmentCommand command) {
		// validate command
		ShipmentCancelledEvent shipmentCancelledEvent=ShipmentCancelledEvent
				.builder()
				.shipmentId(command.getShipmentId())
				.paymentId(command.getPaymentId())
				.orderId(command.getOrderId())
				.shipmentStatus(command.getShipmentStatus())
				.build();	

		AggregateLifecycle.apply(shipmentCancelledEvent);
	}

	@EventSourcingHandler
	public void on(CancelShipmentCommand cancelShipmentCommand) {
		
		this.shipmentStatus=cancelShipmentCommand.getShipmentStatus();
	}
}
