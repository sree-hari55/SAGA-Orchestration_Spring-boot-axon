package com.saga.shipmentservice.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Shipment {

	@Id
	protected String shipmentId;
	protected String orderId;
	protected String shipmentStatus;
}
