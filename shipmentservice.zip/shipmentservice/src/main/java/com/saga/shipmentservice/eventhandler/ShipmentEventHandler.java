
package com.saga.shipmentservice.eventhandler;

import org.axonframework.eventhandling.EventHandler;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.saga.event.OrderShipedEvent;
import com.saga.event.ShipmentCancelledEvent;
import com.saga.shipmentservice.entity.Shipment;
import com.saga.shipmentservice.repository.ShipmentRepository;

@Component
public class ShipmentEventHandler {

	@Autowired
	private ShipmentRepository shipmentRepository;

	@EventHandler
	public void on(OrderShipedEvent orderShipedEvent) {
		Shipment shipment=new Shipment();
		BeanUtils.copyProperties(orderShipedEvent, shipment);
		shipmentRepository.save(shipment);
	}

	@EventHandler
	public void on(ShipmentCancelledEvent shipmentCancelledEvent) {
		// 1st approach
		Shipment shipment=shipmentRepository.findById(shipmentCancelledEvent.getShipmentId()).get();
		shipment.setShipmentStatus(shipmentCancelledEvent.getShipmentStatus());
		shipmentRepository.save(shipment);
		
		//2nd approach we can delete the recor as well
		
	//	shipmentRepository.deleteById(shipmentCancelledEvent.getShipmentId());
	}
}
