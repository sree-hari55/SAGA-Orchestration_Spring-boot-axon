package com.saga.shipmentservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.saga.shipmentservice.entity.Shipment;

public interface ShipmentRepository extends JpaRepository<Shipment, String>{

}
